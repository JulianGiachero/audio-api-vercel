from fastapi import FastAPI, File, UploadFile
from fastapi.responses import FileResponse, JSONResponse
import os

app = FastAPI()
UPLOAD_FOLDER = "api/audios"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

@app.post("/upload-audio")
async def upload_audio(audio: UploadFile = File(...)):
    filepath = os.path.join(UPLOAD_FOLDER, audio.filename)
    with open(filepath, "wb") as buffer:
        buffer.write(await audio.read())
    return {"mensaje": "Archivo guardado correctamente", "nombre": audio.filename}

@app.get("/audio/{filename}")
async def get_audio(filename: str):
    file_path = os.path.join(UPLOAD_FOLDER, filename)
    if os.path.exists(file_path):
        return FileResponse(file_path, media_type="audio/mpeg")
    return JSONResponse(status_code=404, content={"error": "Archivo no encontrado"})
